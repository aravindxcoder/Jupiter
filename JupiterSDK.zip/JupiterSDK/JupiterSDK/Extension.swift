//
//  Extension.swift
//  Jupiter
//
//  Created by Aravind Devireddy on 13/09/24.
//

import UIKit
import Alamofire

class UserModel: NSObject {
    
    static let shared = UserModel()
    private override init() { }
    
    var mobileNumber = ""
    var studentDetails = StudentDetails(
            StudentRecordId: "",
            StudentName: "",
            Section: "",
            RollNumber: "",
            ProfileImageString: "",
            MotherPhoneNumber: "",
            MotherName: "",
            Gender: "",
            FatherPhoneNumber: "",
            FatherName: "",
            Email: "",
            DOB: "",
            ClassName: "",
            TotalPaidAmount: 0,
            TotalAbsenstInYear: 0,
            TotalFee: 0,
            DueAmount: 0
        )
    var resultData: [MarksDetails] = []
    var feePayment: [FeePaymentsDetails] = []
    var absents: [AbsentsDetails] = []
    var announcements: [ClassAnnouncementDetails] = []
    var absentCount: AbsentsCountDetails = AbsentsCountDetails(
            SeptemberCount: 0,
            OctoberCount: 0,
            NovemberCount: 0,
            MayCount: 0,
            MarchCount: 0,
            JuneCount: 0,
            JulyCount: 0,
            JanuaryCount: 0,
            FebruaryCount: 0,
            DecemberCount: 0,
            AugustCount: 0,
            AprilCount: 0,
            Red: 0.0,
            Orange: 0.0,
            Blue: 0.0
        )
    
    func clearData()  {
        UserModel.shared.mobileNumber = ""
        UserModel.shared.resultData = []
        UserModel.shared.feePayment = []
        UserModel.shared.absents = []
        UserModel.shared.announcements = []
        UserModel.shared.studentDetails = StudentDetails(
                   StudentRecordId: "",
                   StudentName: "",
                   Section: "",
                   RollNumber: "",
                   ProfileImageString: "",
                   MotherPhoneNumber: "",
                   MotherName: "",
                   Gender: "",
                   FatherPhoneNumber: "",
                   FatherName: "",
                   Email: "",
                   DOB: "",
                   ClassName: "",
                   TotalPaidAmount: 0,
                   TotalAbsenstInYear: 0,
                   TotalFee: 0,
                   DueAmount: 0
               )
    }
}


class NetworkManager {
    
    // Singleton instance
    static let shared = NetworkManager()
    
    private var loadingImageView: UIImageView?
    private var loadingBackgroundView: UIView?
    private var fetchingLabel: UILabel?
    private var loadingViewController: LoadingViewController?

    private init() {}

    // Function to check if the device is connected to the internet
    func isConnectedToNetwork() -> Bool {
        return NetworkReachabilityManager()?.isReachable ?? false
    }
    
    // Function to start the network activity indicator (show loading image and message)
    func showLoadingIndicator(on view: UIView) {
        // Create a semi-transparent background view
        loadingBackgroundView = UIView(frame: view.bounds)
        loadingBackgroundView?.backgroundColor = UIColor(white: 0, alpha: 0.5) // Semi-transparent background
        loadingBackgroundView?.translatesAutoresizingMaskIntoConstraints = false
        
        // Add background view to the main view
        view.addSubview(loadingBackgroundView!)
        loadingBackgroundView!.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            loadingBackgroundView!.topAnchor.constraint(equalTo: view.topAnchor),
            loadingBackgroundView!.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            loadingBackgroundView!.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            loadingBackgroundView!.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        
        // Create loading image view
        let image = UIImage(named: "loading") // Your custom loading image
        loadingImageView = UIImageView(image: image)
        loadingImageView?.contentMode = .scaleAspectFit
        loadingImageView?.translatesAutoresizingMaskIntoConstraints = false
        
        // Add loading image view to the background view
        loadingBackgroundView?.addSubview(loadingImageView!)
        
        // Center the loading image
        NSLayoutConstraint.activate([
            loadingImageView!.centerXAnchor.constraint(equalTo: loadingBackgroundView!.centerXAnchor),
            loadingImageView!.centerYAnchor.constraint(equalTo: loadingBackgroundView!.centerYAnchor),
            loadingImageView!.widthAnchor.constraint(equalToConstant: 85),  // Set your desired width
            loadingImageView!.heightAnchor.constraint(equalToConstant: 85) // Set your desired height
        ])
        
        // Create and configure the fetching label
        fetchingLabel = UILabel()
        fetchingLabel?.text = "Fetching Details..."
        fetchingLabel?.textColor = .white
        fetchingLabel?.translatesAutoresizingMaskIntoConstraints = false
        loadingBackgroundView?.addSubview(fetchingLabel!)
        
        // Center the label below the loading image
        NSLayoutConstraint.activate([
            fetchingLabel!.topAnchor.constraint(equalTo: loadingImageView!.bottomAnchor, constant: 20),
            fetchingLabel!.centerXAnchor.constraint(equalTo: loadingBackgroundView!.centerXAnchor)
        ])
        
        // Start the loading animation
        startLoadingAnimation()
    }
    
    // Function to hide the network activity indicator (hide loading image and message)
    func hideLoadingIndicator() {
        stopLoadingAnimation()
        
        // Remove the loading image and background view from the superview
        loadingImageView?.removeFromSuperview()
        loadingBackgroundView?.removeFromSuperview()
        
        // Reset loading views to nil
        loadingImageView = nil
        loadingBackgroundView = nil
        fetchingLabel = nil
    }
    
    // Optional: Start a loading animation (e.g., rotating the image)
    private func startLoadingAnimation() {
        guard let loadingImageView = loadingImageView else { return }
        
        // Create a rotation animation
        let rotation = CABasicAnimation(keyPath: "transform.rotation.z")
        rotation.toValue = NSNumber(value: Double.pi * 2) // 360 degrees
        rotation.duration = 1.0 // Duration of one full rotation
        rotation.isCumulative = true
        rotation.repeatCount = Float.infinity // Infinite repeat
        
        loadingImageView.layer.add(rotation, forKey: "rotationAnimation")
    }
    
    func showLoading_Indicator(on viewController: UIViewController) {
            // Create and configure the loading view controller
            loadingViewController = LoadingViewController()
            loadingViewController?.modalPresentationStyle = .overFullScreen
            
            // Present the loading view controller
            viewController.present(loadingViewController!, animated: false, completion: {
                self.loadingViewController?.startLoadingAnimation()
            })
        }
        
        func hideLoading_Indicator() {
            loadingViewController?.stopLoadingAnimation()
            loadingViewController?.dismiss(animated: false, completion: {
                self.loadingViewController = nil
            })
        }
    
    // Optional: Stop the loading animation
    private func stopLoadingAnimation() {
        loadingImageView?.layer.removeAllAnimations()
    }
}

class LoadingViewController: UIViewController {
    
    private var loadingImageView: UIImageView!
    private var fetchingLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    private func setupUI() {
        view.backgroundColor = UIColor(white: 0, alpha: 0.5) // Semi-transparent background
        
        loadingImageView = UIImageView(image: UIImage(named: "loading"))
        loadingImageView.contentMode = .scaleAspectFit
        loadingImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(loadingImageView)
        
        // Center the loading image
        NSLayoutConstraint.activate([
            loadingImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loadingImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            loadingImageView.widthAnchor.constraint(equalToConstant: 85),
            loadingImageView.heightAnchor.constraint(equalToConstant: 85)
        ])
        
        fetchingLabel = UILabel()
        fetchingLabel.text = "Fetching Details..."
        fetchingLabel.textColor = .white
        fetchingLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(fetchingLabel)
        
        // Center the label below the loading image
        NSLayoutConstraint.activate([
            fetchingLabel.topAnchor.constraint(equalTo: loadingImageView.bottomAnchor, constant: 20),
            fetchingLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func startLoadingAnimation() {
        // Create a rotation animation
        let rotation = CABasicAnimation(keyPath: "transform.rotation.z")
        rotation.toValue = NSNumber(value: Double.pi * 2) // 360 degrees
        rotation.duration = 1.0 // Duration of one full rotation
        rotation.isCumulative = true
        rotation.repeatCount = Float.infinity // Infinite repeat
        
        loadingImageView.layer.add(rotation, forKey: "rotationAnimation")
    }
    
    func stopLoadingAnimation() {
        loadingImageView.layer.removeAllAnimations()
    }
}
