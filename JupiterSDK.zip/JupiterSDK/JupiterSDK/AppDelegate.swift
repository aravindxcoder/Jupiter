//
//  AppDelegate.swift
//  JupiterSDK
//
//  Created by Aravind Devireddy on 27/09/24.
//

import UIKit
import FirebaseCore

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        navigationAndTabBarSetup()
        FirebaseApp.configure()
        return true
    }

    // MARK: UISceneSession Lifecycle

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    func navigationAndTabBarSetup() {
        let NAVIGATIONBAR_COLOR = UIColor.blue
        
        if #available(iOS 13.0, *) {
            let navBarAppearance = UINavigationBarAppearance()
            navBarAppearance.configureWithOpaqueBackground()
            navBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
            navBarAppearance.backgroundColor = NAVIGATIONBAR_COLOR
            
            UINavigationBar.appearance().standardAppearance = navBarAppearance
            UINavigationBar.appearance().scrollEdgeAppearance = navBarAppearance
            UINavigationBar.appearance().prefersLargeTitles = false
            UINavigationBar.appearance().isTranslucent = true
            UINavigationBar.appearance().tintColor = UIColor.white
            
            let tabBarAppearance = UITabBarAppearance()
            tabBarAppearance.configureWithOpaqueBackground()
            UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: NAVIGATIONBAR_COLOR], for: .selected)
            UITabBar.appearance().tintColor = NAVIGATIONBAR_COLOR
            
            if #available(iOS 15.0, *) {
                UITabBar.appearance().scrollEdgeAppearance = tabBarAppearance
            }
        } else {
            UINavigationBar.appearance().isTranslucent = true
            UINavigationBar.appearance().barTintColor = NAVIGATIONBAR_COLOR
            UINavigationBar.appearance().tintColor = UIColor.white
            UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.white]
            
            UITabBar.appearance().tintColor = NAVIGATIONBAR_COLOR
            window?.backgroundColor = NAVIGATIONBAR_COLOR
        }
    }


}

