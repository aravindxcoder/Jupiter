//
//  API Utilities.swift
//  Jupiter
//
//  Created by Aravind Devireddy on 18/09/24.
//


import Foundation
import Alamofire
import CommonCrypto
import UIKit


//MARK: - UIVIEWCONTROLLER
extension UIViewController: UIDocumentPickerDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    // - IMAGE PICKER -
      func imagePicker() {
          if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
              let myPickerController = UIImagePickerController()
          //  myPickerController.mediaTypes = [""]
              myPickerController.delegate = self
              myPickerController.modalPresentationStyle = .fullScreen
              myPickerController.sourceType = .photoLibrary
              UINavigationBar.appearance().backgroundColor = .cyan

            present(myPickerController, animated: true, completion: nil)
          }
      }
    
    // - CAMERA PICKER -
    func cameraPicker(){
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            let cameraPickerController = UIImagePickerController()
            cameraPickerController.delegate = self
            cameraPickerController.sourceType = .camera
            cameraPickerController.allowsEditing = true
            cameraPickerController.modalPresentationStyle = .fullScreen
            UINavigationBar.appearance().backgroundColor = .cyan
            self.present(cameraPickerController, animated: true, completion: nil)
        }
    }
    
    func showAlertViewWithMessage(_ alertMessage : String) {
        let alertVC = UIAlertController.init(title: "", message: alertMessage, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction.init(title: "Ok", style: .cancel, handler: nil))
        self.present(alertVC, animated: true, completion: nil)
    }
    
    func showAlertInstructions(Title: String, message: String) {
        let alertController = UIAlertController(title: "", message: "", preferredStyle: .alert)

           //to change font of title and message.
        let titleFont = [NSAttributedString.Key.font: UIFont(name: "ArialHebrew-Bold", size: 16.0)!]
        let messageFont = [NSAttributedString.Key.font: UIFont(name: "Avenir-Roman", size: 16.0)!]

        let titleAttrString = NSMutableAttributedString(string: Title, attributes: titleFont)
        let messageAttrString = NSMutableAttributedString(string: message, attributes: messageFont)

           alertController.setValue(titleAttrString, forKey: "attributedTitle")
           alertController.setValue(messageAttrString, forKey: "attributedMessage")


           let okAction = UIAlertAction(title: "Ok", style: .default) { (action) in
            print("\(String(describing: action.title))")
           }

           alertController.addAction(okAction)

        alertController.view.tintColor = UIColor.blue
        alertController.view.backgroundColor = UIColor.white//UIColor.black
        alertController.view.layer.cornerRadius = 40

           present(alertController, animated: true, completion: nil)
    }
    
    func formattedDateFromString(dateString: String, withFormat format: String) -> String {

        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "yyyy-MM-dd"//"dd-MMM-yyyy"

        if let date = inputFormatter.date(from: dateString) {

            let outputFormatter = DateFormatter()
          outputFormatter.dateFormat = format

            return outputFormatter.string(from: date)
        }

        return dateString
    }
    
}


//MARK: - API Request Data
struct LoginApi_Request_Data: Codable {
    let grant_type, client_id, client_secret, username, password: String
}


//MARK: - API Response Data
struct Login_API_Response_Data: Codable {
    let access_token, instance_url, id, token_type, issued_at, signature: String?
}

//MARK: - GET API Response Details
struct StudentDetails: Codable {
    let StudentRecordId, StudentName, Section, RollNumber, ProfileImageString, MotherPhoneNumber, MotherName, Gender, FatherPhoneNumber, FatherName, Email, DOB, ClassName: String?
    let TotalPaidAmount, TotalAbsenstInYear, TotalFee, DueAmount: Int?
}

struct StudentAnnouncementDetails: Codable {
    
}

struct SchoolDetails: Codable {
    let SchoolShortName, SchoolName, SchoolContactNumber, PrincipalPhoneNumber, PrincipalName, AcademicYear : String?
}

struct SchoolAnnouncementDetails: Codable {
    
}

struct MarksDetails: Codable {
    let TotalMarks: Double?
    let Social, SecondLanguage, Science, Percentange, MinMarks, MaxMarks, Maths, Firstlanguage, English: Int?
    let Result, Message, MarksRecordId, Grade, ExamRecordId, ExamName: String?
}


struct FeePaymentsDetails: Codable {
    let paymentType, PaymentRecordId, PaymentMonth, PaymentDate: String?
    let HideFromMobileView: Bool?
    let AmountPaid: Int?
}

struct ClasssDetails: Codable {
    let PhoneNumber, ClassTeacherName, ClassName: String?
}

struct ClassAnnouncementDetails: Codable {
    let startDate, Message, endDate, ClassAnnouncementRecordId: String?
}

struct AbsentsDetails: Codable {
    let DateOfAbsent, AbsentType, AbsentRecordId, Absentcount:  String?
}

struct AbsentsCountDetails: Codable {
    let SeptemberCount, OctoberCount, NovemberCount, MayCount, MarchCount, JuneCount, JulyCount, JanuaryCount, FebruaryCount, DecemberCount, AugustCount, AprilCount: Int?
    let Red, Orange, Blue: Double?
       
}

//MARK: - API RESPONSE
struct ResponseFullDetails: Codable {
    let StudentDetails: StudentDetails?
    let StudentAnnouncementDetails: [StudentAnnouncementDetails]?
    let SchoolDetails: SchoolDetails?
    let SchoolAnnouncementDetails: [SchoolAnnouncementDetails]?
    let MarksDetails: [MarksDetails]?
    let FeePaymentsDetails: [FeePaymentsDetails]?
    let ClasssDetails: ClasssDetails?
    let ClassAnnouncementDetails: [ClassAnnouncementDetails]?
    let AbsentsDetails: [AbsentsDetails]?
    let AbsentsCountDetails: AbsentsCountDetails?
}
