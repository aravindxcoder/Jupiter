//
//  AbsentsViewController.swift
//  Jupiter
//
//  Created by Aravind Devireddy on 16/09/24.
//

import UIKit
import DGCharts
import Alamofire


@available(iOS 13.0, *)
class AbsentsViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableChartBarView: UIView!
    
    var barChartView: BarChartView!
    var loginResponse: Login_API_Response_Data?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp()
        setupBarChart()
    }
    
    
    
    func initialSetUp() {
        tableView.backgroundColor = .systemBackground
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 40
        tableView.register(UINib(nibName: "AbsentsHistoryCell", bundle: nil), forCellReuseIdentifier: "AbsentsHistoryCellID")
        
        barChartView = BarChartView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 300))
        self.tableChartBarView.addSubview(barChartView)
    }
    
    
    func setupBarChart() {
        let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        
        var absenteeValues: [Double] = []
        
        let januaryCount = UserModel.shared.absentCount.JanuaryCount ?? 0
        let februaryCount = UserModel.shared.absentCount.FebruaryCount ?? 0
        let marchCount = UserModel.shared.absentCount.MarchCount ?? 2
        let aprilCount = UserModel.shared.absentCount.AprilCount ?? 3
        let mayCount = UserModel.shared.absentCount.MayCount ?? 0
        let juneCount = UserModel.shared.absentCount.JuneCount ?? 0
        let julyCount = UserModel.shared.absentCount.JulyCount ?? 0
        let augustCount = UserModel.shared.absentCount.AugustCount ?? 0
        let septemberCount = UserModel.shared.absentCount.SeptemberCount ?? 0
        let octoberCount = UserModel.shared.absentCount.OctoberCount ?? 0
        let novemberCount = UserModel.shared.absentCount.NovemberCount ?? 0
        let decemberCount = UserModel.shared.absentCount.DecemberCount ?? 0
        
        absenteeValues.append(Double(januaryCount))
        absenteeValues.append(Double(februaryCount))
        absenteeValues.append(Double(marchCount))
        absenteeValues.append(Double(aprilCount))
        absenteeValues.append(Double(mayCount))
        absenteeValues.append(Double(juneCount))
        absenteeValues.append(Double(julyCount))
        absenteeValues.append(Double(augustCount))
        absenteeValues.append(Double(septemberCount))
        absenteeValues.append(Double(octoberCount))
        absenteeValues.append(Double(novemberCount))
        absenteeValues.append(Double(decemberCount))
        
        var absenteeColors: [UIColor] = []
        
        for absenteeValue in absenteeValues {
            let value = Double(absenteeValue)
            
            let color: UIColor
            if value <= 2 {
                color = .blue
            } else {
                color = .orange
            }
            absenteeColors.append(color)
        }
        
        var absenteeEntries: [BarChartDataEntry] = []
        for (index, dataValue) in absenteeValues.enumerated() {
            let entry = BarChartDataEntry(x: Double(index), y: dataValue)
            absenteeEntries.append(entry)
        }
        
        let absenteeDataSet = BarChartDataSet(entries: absenteeEntries, label: "Absentees")
        absenteeDataSet.colors = absenteeColors
        
        let chartData = BarChartData(dataSets: [absenteeDataSet])
        chartData.barWidth = 0.4
        
        barChartView.data = chartData
        
        barChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values: months)
        barChartView.xAxis.granularity = 1
        barChartView.xAxis.labelPosition = .bottom
        
        let leftAxis = barChartView.leftAxis
        leftAxis.axisMinimum = 0
        leftAxis.axisMaximum = 15
        
        barChartView.rightAxis.enabled = false
        
        barChartView.animate(yAxisDuration: 1.5)
        barChartView.legend.enabled = true
        barChartView.chartDescription.enabled = false
    }
}

@available(iOS 13.0, *)
extension AbsentsViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return UserModel.shared.absents.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCellIdentifier", for: indexPath) as! AbsentsHistoryCell
        let absent = UserModel.shared.absents[indexPath.row]
        cell.typeLabelText.text = absent.AbsentType
        cell.dateLabelText.text = absent.DateOfAbsent
        cell.backgroundColor = .clear
        return cell
    }
    
}

//MARK: - CELL
class AbsentsHistoryCell: UITableViewCell {
    @IBOutlet weak var dateLabelText: UILabel!
    @IBOutlet weak var typeLabelText: UILabel!

    override class func awakeFromNib() {
        super.awakeFromNib()
    }
    
}
