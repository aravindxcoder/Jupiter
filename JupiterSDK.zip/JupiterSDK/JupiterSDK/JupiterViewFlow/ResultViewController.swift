//
//  ResultViewController.swift
//  Jupiter
//
//  Created by Aravind Devireddy on 16/09/24.
//

import UIKit
import DGCharts

class ResultViewController: UIViewController {
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var subjectBarChartView: UIView!
    
    @IBOutlet var firstlanguagetMaximumMarks: UILabel!
    @IBOutlet var secondLanguageMaximumMarks: UILabel!
    @IBOutlet var englishMaximumMarks: UILabel!
    @IBOutlet var mathsMaximumMarks: UILabel!
    @IBOutlet var scienceMaximumMarks: UILabel!
    @IBOutlet var socialMaximumMarks: UILabel!
    @IBOutlet var totalMaximumMarks: UILabel!
    
    @IBOutlet var firstLanguageGainMarks: UILabel!
    @IBOutlet var secondLanguageGainMarks: UILabel!
    @IBOutlet var englishGainMarks: UILabel!
    @IBOutlet var mathsGainMarks: UILabel!
    @IBOutlet var scienceGainMarks: UILabel!
    @IBOutlet var socialGainMarks: UILabel!
    @IBOutlet var totalGainMarks: UILabel!
    
    @IBOutlet var firstLanguagePercentage: UILabel!
    @IBOutlet var secondLanguagePercentage: UILabel!
    @IBOutlet var englishPercentage: UILabel!
    @IBOutlet var mathsPercentage: UILabel!
    @IBOutlet var sciencePercentage: UILabel!
    @IBOutlet var socialPercentage: UILabel!
    @IBOutlet var totalPercentage: UILabel!
    
    @IBOutlet var resultlbl: UILabel!
    @IBOutlet var gradelbl: UILabel!
    
    @IBOutlet var restulFullView: UIView!
    
    
    var barChartView: BarChartView!
    var loginResponse: Login_API_Response_Data?
    var resultResponse: ResponseFullDetails?
    
    var exams: [MarksDetails]?
    var selectedExam: MarksDetails?
    var firstlanguagePercentages: Double = 0.0
    var secondlanguagePercentages: Double = 0.0
    var englishPercentages: Double = 0.0
    var mathsPercentages: Double = 0.0
    var sciencePercentages: Double = 0.0
    var socialPercentages: Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUP()
        setChartData()
        updateGradeLabel()
        subjectBarChartView.addSubview(barChartView)
        exams = resultResponse?.MarksDetails
        addShadow(to: restulFullView)
    }
    
    func initialSetUP() {
        guard let firstResult = UserModel.shared.resultData.first else {
            return
        }
        
        [firstlanguagetMaximumMarks, secondLanguageMaximumMarks, englishMaximumMarks, mathsMaximumMarks, scienceMaximumMarks, socialMaximumMarks].forEach { label in
            label?.text = "\(firstResult.MaxMarks ?? 0)"
        }
        
        if let maxMarks = firstResult.MaxMarks {
            let multipliedMarks = maxMarks * 6
            totalMaximumMarks.text = "\(multipliedMarks)"
        } else {
            totalMaximumMarks.text = "N/A"
        }
        
        resultlbl.layer.cornerRadius = 10
        resultlbl.clipsToBounds = true
        gradelbl.layer.cornerRadius = 10
        gradelbl.clipsToBounds = true
        gradelbl.backgroundColor = UIColor.green
        resultlbl.backgroundColor = UIColor.green
        
        pickerView.delegate = self
        pickerView.dataSource = self
        
        if !UserModel.shared.resultData.isEmpty {
            firstLanguageGainMarks.text = "\(firstResult.Firstlanguage ?? 0)"
            secondLanguageGainMarks.text = "\(firstResult.SecondLanguage ?? 0)"
            englishGainMarks.text = "\(firstResult.English ?? 0)"
            mathsGainMarks.text = "\(firstResult.Maths ?? 0)"
            scienceGainMarks.text = "\(firstResult.Science ?? 0)"
            socialGainMarks.text = "\(firstResult.Social ?? 0)"
            
            totalGainMarks.text = "\(firstResult.TotalMarks ?? 0)"
            totalPercentage.text = "\(firstResult.Percentange ?? 0)%"
            
            resultlbl.text = firstResult.Result ?? "N/A"
            gradelbl.text = firstResult.Grade ?? "N/A"
        }
        
        if let firstLanguageGainText = firstLanguageGainMarks.text,
           let englishGainText = englishGainMarks.text,
           let mathsGainText = mathsGainMarks.text,
           let scienceGainText = scienceGainMarks.text,
           let socialGainText = socialGainMarks.text,
           let secondLanguageGainText = secondLanguageGainMarks.text {
            
            let firstLanguageGain = Double(firstLanguageGainText) ?? 0
            let englishGain = Double(englishGainText) ?? 0
            let mathsGain = Double(mathsGainText) ?? 0
            let scienceGain = Double(scienceGainText) ?? 0
            let socialGain = Double(socialGainText) ?? 0
            let secondLanguageGain = Double(secondLanguageGainText) ?? 0
            
            let firstLanguageMax = firstResult.MaxMarks ?? 0
            let secondLanguageMax = firstResult.MaxMarks ?? 0
            let englishMax = firstResult.MaxMarks ?? 0
            let mathsMax = firstResult.MaxMarks ?? 0
            let scienceMax = firstResult.MaxMarks ?? 0
            let socialMax = firstResult.MaxMarks ?? 0
            
            if firstLanguageMax > 0, englishMax > 0, mathsMax > 0, scienceMax > 0, socialMax > 0, secondLanguageMax > 0 {
                firstlanguagePercentages = (firstLanguageGain / Double(firstLanguageMax)) * 100
                englishPercentages = (englishGain / Double(englishMax)) * 100
                mathsPercentages = (mathsGain / Double(mathsMax)) * 100
                sciencePercentages = (scienceGain / Double(scienceMax)) * 100
                socialPercentages = (socialGain / Double(socialMax)) * 100
                secondlanguagePercentages = (secondLanguageGain / Double(secondLanguageMax)) * 100
            } else {
                print("Error: One or more max marks values are zero.")
            }
            
        } else {
            print("Error: Unable to convert one or more gained marks to a valid number.")
        }
        
        firstLanguagePercentage.text = "\(firstlanguagePercentages)%"
        secondLanguagePercentage.text = "\(secondlanguagePercentages)%"
        englishPercentage.text = "\(englishPercentages)%"
        mathsPercentage.text = "\(mathsPercentages)%"
        sciencePercentage.text = "\(sciencePercentages)%"
        socialPercentage.text = "\(socialPercentages)%"
        
        barChartView = BarChartView()
        barChartView.translatesAutoresizingMaskIntoConstraints = false
        
        subjectBarChartView.addSubview(barChartView)
        
        NSLayoutConstraint.activate([
            barChartView.topAnchor.constraint(equalTo: subjectBarChartView.topAnchor),
            barChartView.leadingAnchor.constraint(equalTo: subjectBarChartView.leadingAnchor),
            barChartView.trailingAnchor.constraint(equalTo: subjectBarChartView.trailingAnchor),
            barChartView.bottomAnchor.constraint(equalTo: subjectBarChartView.bottomAnchor)
        ])
        
        barChartView.rightAxis.enabled = false
        barChartView.leftAxis.axisMinimum = 0
        barChartView.leftAxis.axisMaximum = 30
        barChartView.xAxis.granularity = 1
        barChartView.xAxis.labelPosition = .bottom
        barChartView.animate(yAxisDuration: 1.5)
    }
    
    func updateGradeLabel() {
        guard let selectedExam = selectedExam else { return }
        resultlbl.backgroundColor = (selectedExam.Result == "Pass") ? UIColor.green : UIColor.red
    }
    
    func setChartData() {
        let subjects: [String] = ["F.L", "S.L", "Eng", "Math", "Sci", "Soc"]
        let scores: [Double] = [
            Double(UserModel.shared.resultData.first?.Firstlanguage ?? 0),
            Double(UserModel.shared.resultData.first?.SecondLanguage ?? 0),
            Double(UserModel.shared.resultData.first?.English ?? 0),
            Double(UserModel.shared.resultData.first?.Maths ?? 0),
            Double(UserModel.shared.resultData.first?.Science ?? 0),
            Double(UserModel.shared.resultData.first?.Social ?? 0)
        ]
        let dataEntries = zip(0..<subjects.count, scores).map { index, score in
            BarChartDataEntry(x: Double(index), y: score)
        }
        
        let chartDataSet = BarChartDataSet(entries: dataEntries, label: "Scores")
        chartDataSet.colors = scores.map { $0 == 9.0 ? UIColor.red : UIColor.green }
        
        let chartData = BarChartData(dataSet: chartDataSet)
        barChartView.data = chartData
        
        barChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values: subjects)
    }
    
    func addShadow(to view: UIView) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.2
        view.layer.shadowOffset = CGSize(width: 2, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
}

// MARK: - UIPickerView DataSource and Delegate Methods
extension ResultViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return UserModel.shared.resultData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        guard row < UserModel.shared.resultData.count else { return nil }
        let examName = UserModel.shared.resultData[row].ExamName ?? "N/A"
        return examName
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        guard row < UserModel.shared.resultData.count else { return }
        selectedExam = UserModel.shared.resultData[row]
        updateGradeLabel()
        updateUIForSelectedExam()
    }
    
    func updateUIForSelectedExam() {
        guard let selectedExam = selectedExam else { return }
        firstLanguageGainMarks.text = "\(selectedExam.Firstlanguage ?? 0)"
        secondLanguageGainMarks.text = "\(selectedExam.SecondLanguage ?? 0)"
        englishGainMarks.text = "\(selectedExam.English ?? 0)"
        mathsGainMarks.text = "\(selectedExam.Maths ?? 0)"
        scienceGainMarks.text = "\(selectedExam.Science ?? 0)"
        socialGainMarks.text = "\(selectedExam.Social ?? 0)"
        
        var firstLanguageMax = selectedExam.MaxMarks ?? 0
        var secondLanguageMax = selectedExam.MaxMarks ?? 0
        var englishMax = selectedExam.MaxMarks ?? 0
        var mathsMax = selectedExam.MaxMarks ?? 0
        var scienceMax = selectedExam.MaxMarks ?? 0
        var socialMax = selectedExam.MaxMarks ?? 0
        
        if firstLanguageMax > 0 {
            firstlanguagePercentages = (Double(selectedExam.Firstlanguage ?? 0) / Double(firstLanguageMax)) * 100
        }
        if secondLanguageMax > 0 {
            secondlanguagePercentages = (Double(selectedExam.SecondLanguage ?? 0) / Double(secondLanguageMax)) * 100
        }
        if englishMax > 0 {
            englishPercentages = (Double(selectedExam.English ?? 0) / Double(englishMax)) * 100
        }
        if mathsMax > 0 {
            mathsPercentages = (Double(selectedExam.Maths ?? 0) / Double(mathsMax)) * 100
        }
        if scienceMax > 0 {
            sciencePercentages = (Double(selectedExam.Science ?? 0) / Double(scienceMax)) * 100
        }
        if socialMax > 0 {
            socialPercentages = (Double(selectedExam.Social ?? 0) / Double(socialMax)) * 100
        }
        
        firstLanguagePercentage.text = "\(firstlanguagePercentages)%"
        secondLanguagePercentage.text = "\(secondlanguagePercentages)%"
        englishPercentage.text = "\(englishPercentages)%"
        mathsPercentage.text = "\(mathsPercentages)%"
        sciencePercentage.text = "\(sciencePercentages)%"
        socialPercentage.text = "\(socialPercentages)%"
        
        self.gradelbl.text = "\(selectedExam.Grade ?? "")"
        self.resultlbl.text = "\(selectedExam.Result ?? "")"
        self.totalGainMarks.text = "\(selectedExam.TotalMarks ?? 0)"
        self.totalPercentage.text = "\(selectedExam.Percentange ?? 0)%"
        
        firstLanguageGainMarks.text = "\(selectedExam.Firstlanguage ?? 0)"
        secondLanguageGainMarks.text = "\(selectedExam.SecondLanguage ?? 0)"
        englishGainMarks.text = "\(selectedExam.English ?? 0)"
        mathsGainMarks.text = "\(selectedExam.Maths ?? 0)"
        scienceGainMarks.text = "\(selectedExam.Science ?? 0)"
        socialGainMarks.text = "\(selectedExam.Social ?? 0)"
        
        firstLanguageMax = selectedExam.MaxMarks ?? 0
        if firstLanguageMax > 0 {
            let firstLanguageGain = Double(selectedExam.Firstlanguage ?? 0)
            firstlanguagePercentages = (firstLanguageGain / Double(firstLanguageMax)) * 100
        }
        
        firstLanguagePercentage.text = "\(firstlanguagePercentages)%"
        
        secondLanguageMax = selectedExam.MaxMarks ?? 0
        if secondLanguageMax > 0 {
            let secondLanguageGain = Double(selectedExam.SecondLanguage ?? 0)
            secondlanguagePercentages = (secondLanguageGain / Double(secondLanguageMax)) * 100
        }
        secondLanguagePercentage.text = "\(secondlanguagePercentages)%"
        
        let subjects: [String] = ["F.L", "S.L", "Eng", "Math", "Sci", "Soc"]
        let scores: [Double] = [
            Double(selectedExam.Firstlanguage ?? 0),
            Double(selectedExam.SecondLanguage ?? 0),
            Double(selectedExam.English ?? 0),
            Double(selectedExam.Maths ?? 0),
            Double(selectedExam.Science ?? 0),
            Double(selectedExam.Social ?? 0)
        ]
        
        let dataEntries = zip(0..<subjects.count, scores).map { index, score in
            BarChartDataEntry(x: Double(index), y: score)
        }
        
        let chartDataSet = BarChartDataSet(entries: dataEntries, label: "Scores")
        chartDataSet.colors = scores.map { $0 <= 9.0 ? UIColor.red : UIColor.green }
        
        let chartData = BarChartData(dataSet: chartDataSet)
        barChartView.data = chartData
        
        barChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values: subjects)
    }
}

