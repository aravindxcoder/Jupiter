//
//  MainTabBarViewController.swift
//  Jupiter
//
//  Created by Aravind Devireddy on 14/09/24.
//

import UIKit
import Alamofire


@available(iOS 16.0, *)
class MainTabBarViewController: UITabBarController {
    var isTabBarInteractionEnabled: Bool = true {
        didSet {
            self.tabBar.isUserInteractionEnabled = isTabBarInteractionEnabled
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
