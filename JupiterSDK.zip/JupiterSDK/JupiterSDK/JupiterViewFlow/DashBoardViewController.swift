//
//  DashBoardViewController.swift
//  Jupiter
//
//  Created by Aravind Devireddy on 13/09/24.
//

import UIKit
import Alamofire
import AVFoundation

@available(iOS 16.0, *)
class DashBoardViewController: UIViewController {
    
    @IBOutlet weak var profileView: UIView!
    @IBOutlet weak var studentDetailsView: UIView!
    @IBOutlet weak var parentDetailsView: UIView!
    @IBOutlet weak var schoolDetailsView: UIView!
    
    @IBOutlet weak var profileImageButton: UIButton!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var classLabel: UILabel!
    @IBOutlet weak var sectionLabel: UILabel!
    @IBOutlet weak var rollNumberLabel: UILabel!
    
    @IBOutlet weak var studentIDLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var dobLabel: UILabel!
    @IBOutlet weak var feeLabel: UILabel!
    @IBOutlet weak var paidAmountLabel: UILabel!
    @IBOutlet weak var dueAmountLabel: UILabel!
    @IBOutlet weak var totalAbsentsLabel: UILabel!
    
    @IBOutlet weak var fatherNameLabel: UILabel!
    @IBOutlet weak var motherNameLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    
    @IBOutlet weak var schoolNameLabel: UILabel!
    @IBOutlet weak var contactLabel: UILabel!
    @IBOutlet weak var pricipalNameLabel: UILabel!
    @IBOutlet weak var principalPhoneNumLabel: UILabel!
    @IBOutlet weak var classTeacherLabel: UILabel!
    @IBOutlet weak var teachearPhoneNumLabel: UILabel!
    @IBOutlet weak var schoolAddressLabel: UILabel!
    
    var loginResponse: Login_API_Response_Data?
    var selectedPhoto: UIImage?
    var mobibleNumText = ""
    var dateofBirthText = ""
    var loginButton: UIColor?
    var mainTabbarVC: MainTabBarViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        intialSetUp()
        if NetworkManager.shared.isConnectedToNetwork() {
            NetworkManager.shared.showLoadingIndicator(on: view)
            disableTabBar()
            self.getDetails_API()
        }
    }
    
    func intialSetUp() {
        profileView.layer.cornerRadius = 10
        profileView.clipsToBounds = true
        studentDetailsView.layer.cornerRadius = 10
        studentDetailsView.clipsToBounds = true
        parentDetailsView.layer.cornerRadius = 10
        parentDetailsView.clipsToBounds = true
        schoolDetailsView.layer.cornerRadius = 10
        schoolDetailsView.clipsToBounds = true
        
        profileImageButton.layer.cornerRadius = 30
        profileImageButton.clipsToBounds = true
        
        addShadow(to: profileView)
        addShadow(to: studentDetailsView)
        addShadow(to: parentDetailsView)
        addShadow(to: schoolDetailsView)
    }
    
    func addShadow(to view: UIView) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.2
        view.layer.shadowOffset = CGSize(width: 2, height: 2)
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
    }
    
    @IBAction func capturePhoto_BtnAction(_ sender: UIButton) {
        browseToeSign()
    }
    
    func browseToeSign() {
        let actionSheet = UIAlertController()
        actionSheet.view.tintColor = UIColor.darkGray
        
        let camera = UIAlertAction(title: "Camera", style: UIAlertAction.Style.default, handler: { (alert: UIAlertAction!) -> Void in
            self.cameraPicker()
        })
        
        let photo = UIAlertAction(title: "Choose from Gallery", style: UIAlertAction.Style.default, handler: { (alert: UIAlertAction!) -> Void in
            self.imagePicker()
        })
        
        let removePhoto = UIAlertAction(title: "Remove Photo", style: .destructive) { _ in
            self.selectedPhoto = nil
            self.profileImageButton.setImage(UIImage(named: "profileImage"), for: .normal)
        }
        
        let cancel = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil)
        
        actionSheet.addAction(camera)
        actionSheet.addAction(photo)
        actionSheet.addAction(removePhoto)
        actionSheet.addAction(cancel)
        
        self.present(actionSheet, animated: true, completion: nil)
    }
}

@available(iOS 16.0, *)
extension DashBoardViewController: AVCapturePhotoCaptureDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let editedImage = info[.editedImage] as? UIImage {
            selectedPhoto = editedImage
            profileImageButton.setImage(editedImage, for: .normal)
        } else if let originalImage = info[.originalImage] as? UIImage {
            selectedPhoto = originalImage
            profileImageButton.setImage(originalImage, for: .normal)
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}

@available(iOS 16.0, *)
extension DashBoardViewController {
    func getDetails_API() {
        let mobileNumber = UserModel.shared.mobileNumber
        guard let token = loginResponse?.access_token else {
            print("No valid token found.")
            return
        }
        
        let url = "https://class3602-dev-ed.develop.my.salesforce.com/services/apexrest/salesforceData/\(mobileNumber)"
        
        
        if NetworkManager.shared.isConnectedToNetwork() {
            NetworkManager.shared.showLoading_Indicator(on: self)
            
            let headers: HTTPHeaders = [
                "Authorization": "Bearer \(token)",
                "Content-Type": "application/json"
            ]
            AF.request(url, method: .get, headers: headers).response { response in
                self.enableTabBar()
                NetworkManager.shared.hideLoadingIndicator()
             
                guard let data = response.data else {
                    print("No data received from the server.")
                    return
                }
                
                if let jsonString = String(data: data, encoding: .utf8) {
                    print("Raw JSON: \(jsonString)")
                }
                
                do {
                    if let statusCode = response.response?.statusCode, statusCode == 200 {
                        let decoder = JSONDecoder()
                        let fullResponseDetails = try decoder.decode(ResponseFullDetails.self, from: data)
                        
                        // Student Details
                        self.nameLabel.text = fullResponseDetails.StudentDetails?.StudentName ?? "N/A"
                        self.classLabel.text = fullResponseDetails.StudentDetails?.ClassName ?? "N/A"
                        self.sectionLabel.text = fullResponseDetails.StudentDetails?.Section ?? "N/A"
                        self.rollNumberLabel.text = fullResponseDetails.StudentDetails?.RollNumber ?? "N/A"
                        self.studentIDLabel.text = fullResponseDetails.StudentDetails?.StudentRecordId ?? "N/A"
                        self.genderLabel.text = fullResponseDetails.StudentDetails?.Gender ?? "N/A"
                        self.dobLabel.text = fullResponseDetails.StudentDetails?.DOB ?? "N/A"
                        self.feeLabel.text = fullResponseDetails.StudentDetails?.TotalFee.map { "\($0)" } ?? "N/A"
                        self.paidAmountLabel.text = fullResponseDetails.StudentDetails?.TotalPaidAmount.map { "\($0)" } ?? "N/A"
                        self.dueAmountLabel.text = fullResponseDetails.StudentDetails?.DueAmount.map { "\($0)" } ?? "N/A"
                        self.totalAbsentsLabel.text = fullResponseDetails.StudentDetails?.TotalAbsenstInYear.map { "\($0)" } ?? "N/A"
                        self.fatherNameLabel.text = fullResponseDetails.StudentDetails?.FatherName ?? "N/A"
                        self.motherNameLabel.text = fullResponseDetails.StudentDetails?.MotherName ?? "N/A"
                        self.phoneNumberLabel.text = fullResponseDetails.StudentDetails?.FatherPhoneNumber ?? "N/A"
                        self.emailLabel.text = fullResponseDetails.StudentDetails?.Email ?? "N/A"
                        
                        // School Details
                        self.schoolNameLabel.text = fullResponseDetails.SchoolDetails?.SchoolName ?? "N/A"
                        self.contactLabel.text = fullResponseDetails.SchoolDetails?.SchoolContactNumber ?? "N/A"
                        self.pricipalNameLabel.text = fullResponseDetails.SchoolDetails?.PrincipalName ?? "N/A"
                        self.principalPhoneNumLabel.text = fullResponseDetails.SchoolDetails?.PrincipalPhoneNumber ?? "N/A"
                        
                        // Class Details
                        self.classTeacherLabel.text = fullResponseDetails.ClasssDetails?.ClassTeacherName ?? "N/A"
                        self.teachearPhoneNumLabel.text = fullResponseDetails.ClasssDetails?.PhoneNumber ?? "N/A"
                        self.schoolAddressLabel.text = "" // Assuming empty as in your code
                        
                        if let studentDetails = fullResponseDetails.StudentDetails {
                            UserModel.shared.studentDetails = studentDetails
                        }
                        if let resultOfSubjects = fullResponseDetails.MarksDetails {
                            UserModel.shared.resultData = resultOfSubjects
                        }
                        if let feePaymentDetails = fullResponseDetails.FeePaymentsDetails {
                            UserModel.shared.feePayment = feePaymentDetails
                        }
                        if let absentData = fullResponseDetails.AbsentsDetails {
                            UserModel.shared.absents = absentData
                        }
                        if let absentCountData = fullResponseDetails.AbsentsCountDetails {
                            UserModel.shared.absentCount = absentCountData
                        }
                        if let announcements = fullResponseDetails.ClassAnnouncementDetails {
                            UserModel.shared.announcements = announcements
                        }
                    } else {
                        self.showPopupView()
                    }
                } catch let decodingError as DecodingError {
                    switch decodingError {
                    case .typeMismatch(let key, let context):
                        self.showAlertViewWithMessage ("Type mismatch for key \(key): \(context.debugDescription)")
                    case .valueNotFound(let key, let context):
                        self.showAlertViewWithMessage("Value not found for key \(key): \(context.debugDescription)")
                    case .keyNotFound(let key, let context):
                        self.showAlertViewWithMessage("Key not found: \(key) in context: \(context.debugDescription)")
                    case .dataCorrupted(let context):
                        self.showAlertViewWithMessage("Data corrupted: \(context.debugDescription)")
                    @unknown default:
                        self.showAlertViewWithMessage("Unknown decoding error occurred: \(decodingError)")
                    }
                } catch {
                    self.showAlertViewWithMessage("An unknown error occurred: \(error)")
                }
            }
            
        } else {
            showAlertViewWithMessage("No internet connection")
        }
    }
    
    func showPopupView() {
        disableTabBar()
        if let tabBarController = self.tabBarController {
            print("Tab bar controller found!")
        } else {
            print("No tab bar controller found.")
        }
        let popupViewController = UIViewController()
        popupViewController.modalPresentationStyle = .overFullScreen
        popupViewController.view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        
        let popupContentView = UIView()
        popupContentView.backgroundColor = .white
        popupContentView.layer.cornerRadius = 10
        popupContentView.translatesAutoresizingMaskIntoConstraints = false
        popupViewController.view.addSubview(popupContentView)
        
        NSLayoutConstraint.activate([
            popupContentView.centerXAnchor.constraint(equalTo: popupViewController.view.centerXAnchor),
            popupContentView.centerYAnchor.constraint(equalTo: popupViewController.view.centerYAnchor),
            popupContentView.widthAnchor.constraint(equalToConstant: 300),
            popupContentView.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        let dismissButton = UIButton(type: .system)
        dismissButton.setTitle("Dismiss", for: .normal)
        dismissButton.addTarget(self, action: #selector(dismissPopup), for: .touchUpInside)
        dismissButton.translatesAutoresizingMaskIntoConstraints = false
        popupContentView.addSubview(dismissButton)
        
        let cancelButton = UILabel()
        cancelButton.text = "Student Data Not Found!"
        cancelButton.textColor = .red
        cancelButton.translatesAutoresizingMaskIntoConstraints = false
        popupContentView.addSubview(cancelButton)
        
        NSLayoutConstraint.activate([
            dismissButton.centerXAnchor.constraint(equalTo: popupContentView.centerXAnchor),
            dismissButton.bottomAnchor.constraint(equalTo: popupContentView.bottomAnchor, constant: -20)
        ])
        
        NSLayoutConstraint.activate([
            cancelButton.centerXAnchor.constraint(equalTo: popupContentView.centerXAnchor),
            cancelButton.bottomAnchor.constraint(equalTo: dismissButton.topAnchor, constant: -10)
        ])
        
        self.present(popupViewController, animated: true, completion: nil)
    }
    
    @objc func dismissPopup() {
        self.enableTabBar()
        self.dismiss(animated: true)
        //        UIView.animate(withDuration: 0.2, animations: {
        //                self.navigationController?.popViewController(animated: false)
        //            })
        self.navigationController?.popViewController(animated: false)
    }
    
    func disableTabBar() {
        if let tabBar = self.mainTabbarVC?.tabBar {
            let overlayView = UIView(frame: tabBar.frame)
            overlayView.backgroundColor = UIColor.clear
            overlayView.tag = 999
            
            tabBar.addSubview(overlayView)
            tabBar.isUserInteractionEnabled = false
        }
    }
    
    func enableTabBar() {
        if let tabBar = self.mainTabbarVC?.tabBar {
            if let overlayView = tabBar.viewWithTag(999) {
                overlayView.removeFromSuperview()
            }
            tabBar.isUserInteractionEnabled = true
        }
    }
}
