//
//  SignInVC.swift
//  JupiterSDK
//
//  Created by Aravind Devireddy on 27/09/24.
//

import UIKit
import SkyFloatingLabelTextField
import Alamofire

@available(iOS 16.0, *)
class SignInVC: UIViewController {
    
    // MARK: - IBOutlets
    @IBOutlet weak var mobileNumberTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var dateOfBirthTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var logInButton: UIButton!
    
    // MARK: - Properties
    private var datePicker = UIDatePicker()
        
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        setupDatePicker()
        logInButton.backgroundColor = UIColor.lightGray
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
            self.view.addGestureRecognizer(tapGesture)
    }
    
    // MARK: - Setup Methods
    private func initialSetup() {
        mobileNumberTextField.keyboardType = .numberPad
        mobileNumberTextField.delegate = self
        mobileNumberTextField.clearButtonMode = .whileEditing
        logInButton.layer.cornerRadius = 10
        logInButton.clipsToBounds = true
    }
    
    private func setupDatePicker() {
        // Configure DatePicker
        datePicker.datePickerMode = .date
        datePicker.maximumDate = Date()
        datePicker.preferredDatePickerStyle = .wheels
        
        dateOfBirthTextField.inputView = datePicker
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(donePressed))
        toolbar.setItems([doneButton], animated: true)
        
        dateOfBirthTextField.inputAccessoryView = toolbar
    }
    
    func validateFields() -> Bool {
        guard let mobileNumber = mobileNumberTextField.text, !mobileNumber.isEmpty else {
            showAlertViewWithMessage("Mobile number is required.")
            return false
        }
        
        guard let dateOfBirth = dateOfBirthTextField.text, !dateOfBirth.isEmpty else {
            showAlertViewWithMessage("Date of Birth is required.")
            return false
        }
        
        if !isValidMobileNumber(mobileNumber) {
            showAlertViewWithMessage("Please enter a valid 10-digit mobile number.")
            return false
        }
        
        if !isValidDateOfBirth(dateOfBirth) {
            showAlertViewWithMessage("Please enter a valid Date of Birth above 18 years.")
            return false
        }
        
        return true
    }
    
    func isValidMobileNumber(_ number: String) -> Bool {
        return number.count == 10 && CharacterSet.decimalDigits.isSuperset(of: CharacterSet(charactersIn: number))
    }
    
    func isValidDateOfBirth(_ dob: String) -> Bool {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        
        if let date = dateFormatter.date(from: dob) {
            let calendar = Calendar.current
            let ageComponents = calendar.dateComponents([.year], from: date, to: Date())
            
            if let age = ageComponents.year, age >= 18 {
                return true
            } else {
                return false
            }
        }
        
        return false
    }
    // MARK: - Action Methods
    @objc func donePressed() {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MMM-yyyy"
        dateOfBirthTextField.text = formatter.string(from: datePicker.date)
        dateOfBirthTextField.resignFirstResponder()
    }
    
    @objc func dismissKeyboard() {
        self.view.endEditing(true)
    }
    
    
    @IBAction func loginButtonTapped(_ sender: UIButton) {
        UserModel.shared.mobileNumber = mobileNumberTextField.text ?? ""
        if validateFields() {
            login_API()
        }
    }
}
// MARK: - UITextFieldDelegate
@available(iOS 16.0, *)
extension SignInVC: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.dateOfBirthTextField {
            textField.resignFirstResponder()
        }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == mobileNumberTextField {
            let currentText = textField.text ?? ""
            let newText = (currentText as NSString).replacingCharacters(in: range, with: string)
            
            if string.isEmpty {
                return true
            }
            
            if newText.count <= 10, let firstChar = newText.first, "6789".contains(firstChar) {
                if newText.count == 10 {
                    logInButton.backgroundColor = UIColor.blue
                } else {
                    logInButton.backgroundColor = UIColor.lightGray
                }
                return CharacterSet.decimalDigits.isSuperset(of: CharacterSet(charactersIn: string))
            } else {
                return false
            }
        }
        return true
    }
}

// MARK: - API
@available(iOS 16.0, *)
extension SignInVC {
    func login_API() {
        let requestData = LoginApi_Request_Data(grant_type: "password",
                                                client_id: "3MVG9XgkMlifdwVBg1lSVB0XJiarz8UEM41XcFC51SAq2o.ufTBiNGy_CbjW1mTdb7pTpzHm8sDbtSMMoTYDd",
                                                client_secret: "7A3EC349B22D8C257BD9AE419AF340D405FB7A47508F7797A2239BB639372A94",
                                                username: "andriodserviceuser@class360.com",
                                                password: "Test@18#IUDflVNADnD6idMxAkXUUxfZP")
        
        let url = "https://login.salesforce.com/services/oauth2/token"
        
        if NetworkManager.shared.isConnectedToNetwork() {
            NetworkManager.shared.showLoadingIndicator(on: self.view)
            
            let encoder = JSONEncoder()
            do {
                let jsonData = try encoder.encode(requestData)
                if let jsonObject = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                    
                    AF.request(url, method: .post, parameters: jsonObject, encoding: URLEncoding.default).response { response in
                        NetworkManager.shared.hideLoadingIndicator()
                        guard let data = response.data else {
                            print("No data received from the server.")
                            return
                        }
                        
                        do {
                            let decoder = JSONDecoder()
                            let loginData = try decoder.decode(Login_API_Response_Data.self, from: data)
                            print("Response received: \(loginData)")
                            self.navigateToNextViewController(with: loginData)
                            
                        } catch let error {
                            print("Error decoding response: \(error)")
                        }
                    }
                }
            } catch {
                print("Error encoding request data: \(error)")
            }
        } else {
            print("No internet connection")
        }
    }
    
    func navigateToNextViewController(with loginResponse: Login_API_Response_Data) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let navigationController = self.navigationController {
            for controller in navigationController.viewControllers {
                if controller is MainTabBarViewController {
                    return
                }
            }
        }
        
        let mainTabBarVC = storyboard.instantiateViewController(withIdentifier: "MainTabBarViewControllerID") as! MainTabBarViewController
        
        let dashBoardNavController = storyboard.instantiateViewController(withIdentifier: "DashBoardViewControllerID") as! DashBoardViewController
        dashBoardNavController.loginResponse = loginResponse // Pass data
        dashBoardNavController.mobibleNumText = mobileNumberTextField.text ?? ""
        dashBoardNavController.dateofBirthText = dateOfBirthTextField.text ?? ""
        dashBoardNavController.loginButton = logInButton.backgroundColor
        dashBoardNavController.tabBarItem = UITabBarItem(title: "Dashboard", image: UIImage(systemName: "house.fill"), tag: 0)
        
        let resultNavController = storyboard.instantiateViewController(withIdentifier: "ResultViewControllerID") as! ResultViewController
        resultNavController.loginResponse = loginResponse // Pass data
        resultNavController.tabBarItem = UITabBarItem(title: "Results", image: UIImage(systemName: "list.bullet.rectangle"), tag: 1)
        
        let paymentNavViewController = storyboard.instantiateViewController(withIdentifier: "FeePaymentViewControllerID") as! FeePaymentViewController
        paymentNavViewController.loginResponse = loginResponse
        paymentNavViewController.tabBarItem = UITabBarItem(title: "Payments", image: UIImage(systemName: "creditcard.fill"), tag: 2)
        
        let absentsNavViewController = storyboard.instantiateViewController(withIdentifier: "AbsentsViewControllerID") as! AbsentsViewController
        absentsNavViewController.loginResponse = loginResponse
        absentsNavViewController.tabBarItem = UITabBarItem(title: "Absents", image: UIImage(systemName: "calendar.badge.exclamationmark"), tag: 3)
        
        let announcementNavViewController = storyboard.instantiateViewController(withIdentifier: "AnnouncementViewControllerID") as! AnnouncementViewController
        announcementNavViewController.loginResponse = loginResponse
        announcementNavViewController.tabBarItem = UITabBarItem(title: "Announcements", image: UIImage(systemName: "megaphone.fill"), tag: 4)
        
        mainTabBarVC.viewControllers = [dashBoardNavController, resultNavController, paymentNavViewController, absentsNavViewController, announcementNavViewController]
        
        let titleName = UIBarButtonItem(title: "SCHVS", style: .plain, target: nil, action: nil)
        mainTabBarVC.navigationItem.leftBarButtonItem = titleName
        
        let logoutButton = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(logoutTapped))
        mainTabBarVC.navigationItem.rightBarButtonItem = logoutButton
        self.navigationController?.navigationBar.isHidden = false
        self.navigationController?.pushViewController(mainTabBarVC, animated: true)
    }
    
    @objc func logoutTapped() {
        let alert = UIAlertController(title: "Logout", message: "Are you sure you want to exit?", preferredStyle: .alert)
        
        let yesAction = UIAlertAction(title: "Yes", style: .destructive) { _ in
            UserModel.shared.clearData()
            self.mobileNumberTextField.text = ""
            self.dateOfBirthTextField.text = ""
            self.logInButton.backgroundColor = UIColor.lightGray
            self.navigationController?.popViewController(animated: true)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alert.addAction(yesAction)
        alert.addAction(cancelAction)
        
        self.present(alert, animated: true, completion: nil)
    }
}
