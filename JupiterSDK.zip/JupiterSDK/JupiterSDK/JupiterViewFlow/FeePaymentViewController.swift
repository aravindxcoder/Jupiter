//
//  FeePaymentViewController.swift
//  Jupiter
//
//  Created by Aravind Devireddy on 16/09/24.
//

import UIKit

class FeePaymentViewController: UIViewController {
    
    @IBOutlet weak var graphView: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    let paidLabel = UILabel()
    let dueLabel = UILabel()
    let paidText = UILabel()
    let dueText = UILabel()
    
    var loginResponse: Login_API_Response_Data?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initialSetUp()
        
        print("Absents Data \(UserModel.shared.feePayment)")
        
        let paid: CGFloat = CGFloat(UserModel.shared.studentDetails.TotalPaidAmount ?? 0)
        let due: CGFloat = CGFloat(UserModel.shared.studentDetails.DueAmount ?? 0)
        let total = paid + due
        
        drawCircularGraph(paid: paid, due: due, total: total)
        
        addLabels(paid: paid, due: due, total: total)
    }
    
    func initialSetUp() {
        if #available(iOS 13.0, *) {
            tableView.backgroundColor = .systemBackground
        } else {
            
        }
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 40
        tableView.register(UINib(nibName: "PaymentHistoryCell", bundle: nil), forCellReuseIdentifier: "PaymentHistoryCellID")
    }
    
    private func drawCircularGraph(paid: CGFloat, due: CGFloat, total: CGFloat) {
        let values: [CGFloat] = [paid, due]
        let colors: [UIColor] = [UIColor.green, UIColor.red]
        
        var startAngle: CGFloat = -.pi / 2
        let radius: CGFloat = 100.0
        let centerPoint = graphView.center
        
        for (index, value) in values.enumerated() {
            let endAngle = startAngle + (2 * .pi * (value / total))
            
            let path = UIBezierPath(arcCenter: centerPoint,
                                    radius: radius,
                                    startAngle: startAngle,
                                    endAngle: endAngle,
                                    clockwise: true)
            
            path.addLine(to: centerPoint)
            path.close()
            
            let shapeLayer = CAShapeLayer()
            shapeLayer.path = path.cgPath
            shapeLayer.fillColor = colors[index].cgColor
            view.layer.addSublayer(shapeLayer)
            
            startAngle = endAngle
        }
        
        addChartLabels(paid: paid, due: due, total: total, centerPoint: centerPoint, radius: radius)
    }
    
    
    private func addChartLabels(paid: CGFloat, due: CGFloat, total: CGFloat, centerPoint: CGPoint, radius: CGFloat) {
        paidLabel.text = "\(Int(paid))"
        paidLabel.textAlignment = .center
        paidLabel.font = UIFont.systemFont(ofSize: 14)
        
        dueLabel.text = "\(Int(due))"
        dueLabel.textAlignment = .center
        dueLabel.font = UIFont.systemFont(ofSize: 14)
        
        paidText.text = "Paid"
        paidText.textAlignment = .center
        paidText.font = UIFont.systemFont(ofSize: 12)
        
        dueText.text = "Due"
        dueText.textAlignment = .center
        dueText.font = UIFont.systemFont(ofSize: 12)
        
        view.addSubview(dueLabel)
        view.addSubview(dueText)
        view.addSubview(paidLabel)
        view.addSubview(paidText)
        dueText.translatesAutoresizingMaskIntoConstraints = false
        dueLabel.translatesAutoresizingMaskIntoConstraints = false
        paidLabel.translatesAutoresizingMaskIntoConstraints = false
        paidText.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            dueLabel.centerXAnchor.constraint(equalTo: graphView.centerXAnchor, constant: -15),
            dueLabel.bottomAnchor.constraint(equalTo: dueText.topAnchor, constant: 2), // Positioned near the top inside the circle
            dueLabel.widthAnchor.constraint(equalToConstant: radius),
            dueLabel.heightAnchor.constraint(equalToConstant: 20)
        ])
        
        NSLayoutConstraint.activate([
            dueText.centerXAnchor.constraint(equalTo: graphView.centerXAnchor, constant: -12),
            dueText.centerYAnchor.constraint(equalTo: graphView.centerYAnchor, constant: -80), // Adjust as needed for positioning inside the circle
            dueText.widthAnchor.constraint(equalToConstant: radius),
            dueText.heightAnchor.constraint(equalToConstant: 20)
        ])
        
        NSLayoutConstraint.activate([
            paidLabel.centerXAnchor.constraint(equalTo: graphView.centerXAnchor),
            paidLabel.bottomAnchor.constraint(equalTo: graphView.bottomAnchor, constant: -140),
            // Positioned below dueText
            paidLabel.widthAnchor.constraint(equalToConstant: radius),
            paidText.heightAnchor.constraint(equalToConstant: 20)
        ])
        
        NSLayoutConstraint.activate([
            paidText.centerXAnchor.constraint(equalTo: graphView.centerXAnchor),
            paidText.topAnchor.constraint(equalTo: paidLabel.bottomAnchor, constant: 2), // Positioned near the bottom inside the circle
            paidText.widthAnchor.constraint(equalToConstant: radius),
            paidText.heightAnchor.constraint(equalToConstant: -20)
        ])
    }
    
    private func addLabels(paid: CGFloat, due: CGFloat, total: CGFloat) {
        let labelWidth: CGFloat = 100
        let labelHeight: CGFloat = 30.0
        let colorIndicatorSize: CGFloat = 15
        let spacing: CGFloat = 4.0
        
        let paidColorIndicator = UIView()
        paidColorIndicator.backgroundColor = .green
        paidColorIndicator.frame = CGRect(x: graphView.center.x - labelWidth - colorIndicatorSize - spacing, y: graphView.center.y + 150 + (labelHeight - colorIndicatorSize) / 2, width: colorIndicatorSize, height: colorIndicatorSize)
        view.addSubview(paidColorIndicator)
        
        let paidLabel = UILabel()
        paidLabel.text = "Paid: \(Int(paid))"
        paidLabel.textAlignment = .center
        paidLabel.font = UIFont.systemFont(ofSize: 16)
        paidLabel.frame = CGRect(x: graphView.center.x - labelWidth, y: graphView.center.y + 150, width: labelWidth, height: labelHeight)
        view.addSubview(paidLabel)
        
        let dueColorIndicator = UIView()
        dueColorIndicator.backgroundColor = .red  // Set to red for due
        dueColorIndicator.frame = CGRect(x: graphView.center.x + 50 - colorIndicatorSize - spacing, y: graphView.center.y + 150 + (labelHeight - colorIndicatorSize) / 2, width: colorIndicatorSize, height: colorIndicatorSize)
        view.addSubview(dueColorIndicator)
        
        let dueLabel = UILabel()
        dueLabel.text = "Due: \(Int(due))"
        dueLabel.textAlignment = .center
        dueLabel.font = UIFont.systemFont(ofSize: 16)
        dueLabel.frame = CGRect(x: graphView.center.x + 50, y: graphView.center.y + 150, width: labelWidth, height: labelHeight)
        view.addSubview(dueLabel)
    }
}
    

extension FeePaymentViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return UserModel.shared.feePayment.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCellIdentifier", for: indexPath) as! PaymentHistoryCell
        let feeHistory = UserModel.shared.feePayment[indexPath.row]
        cell.amountLabelText.text = feeHistory.AmountPaid.map { "\($0)" } ?? ""
        cell.dateLabelText.text = feeHistory.PaymentDate
        cell.backgroundColor = .clear
        return cell
    }
}

//MARK: - CELL
class PaymentHistoryCell: UITableViewCell {
    
    @IBOutlet weak var amountLabelText: UILabel!
    @IBOutlet weak var dateLabelText: UILabel!

    override class func awakeFromNib() {
        super.awakeFromNib()
    }
}
