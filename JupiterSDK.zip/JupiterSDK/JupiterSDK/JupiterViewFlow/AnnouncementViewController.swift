//
//  HomeViewController.swift
//  Jupiter
//
//  Created by Aravind Devireddy on 14/09/24.
//

import UIKit

class AnnouncementViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var loginResponse: Login_API_Response_Data?
    var responseDetails: ResponseFullDetails?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp()
        print("\(UserModel.shared.announcements)")
    }
    
    func initialSetUp() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 40
        tableView.register(UINib(nibName: "AnnouncementCell", bundle: nil), forCellReuseIdentifier: "AnnouncementCellID")
        tableView.backgroundColor = UIColor.white

        tableView.reloadData()
    }
}

extension AnnouncementViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = UserModel.shared.announcements.count ?? 0
        return count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCellIdentifier", for: indexPath) as! AnnouncementCell
        let announcement = UserModel.shared.announcements[indexPath.row]
        cell.startDateLabel.text = announcement.startDate
        cell.messageLabel.text = announcement.Message
        cell.endDateLabel.text = announcement.endDate
        cell.selectionStyle = .none
        cell.backgroundColor = .white
        return cell
    }
}

//MARK: - CELL
class AnnouncementCell: UITableViewCell {
    
    @IBOutlet weak var startDateLabel: UILabel!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var endDateLabel: UILabel!
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
}
